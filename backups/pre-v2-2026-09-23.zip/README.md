# Pehredar.ai — Intelligent Border Video Analytics Platform (IBVAP)

A working demo of the IBVAP idea: turn ordinary IP-CCTV feeds into an
AI-driven border surveillance platform in software, no dedicated FRS/ANPR
hardware required. Indian border-security themed dashboard, 4-camera wall,
and one button per capability in the problem statement.

## What's real vs. simulated

This is a hackathon/demo prototype, so it's built honestly on two tiers —
know which is which before you present it:

**Real, live AI processing (CAM-01):**
- Human detection & tracking — YOLOv8n (COCO-pretrained, person class) +
  a lightweight centroid tracker, running on your webcam or an uploaded/
  sample video
- Virtual fence intrusion detection — point-in-polygon test against live
  tracked positions
- Suspicious activity detection — loitering (dwell radius) and fast
  movement, computed from real track history
- Night-time movement detection — auto-triggered from real frame
  brightness
- **SHA-256 hash-chained event log** — every event's hash covers the
  previous event's hash plus its own snapshot bytes. This is a genuine
  tamper-evidence mechanism, not a mock: edit a row or swap a snapshot on
  disk and `/api/integrity` (`verify_chain()` in `analytics.py`) will
  detect exactly where the chain breaks. Confirmed by test: corrupting a
  snapshot file makes `verified` flip to `false` and names the event id.

**Real, model-driven (CAM-02 source clip, on an interval — `anpr.py:
ANPRProcessor`):**
- Vehicle-type detection & classification (SUV / compact / sedan) — a
  custom-trained YOLOv8 model (`models/anpr_best.pt`), brought in from the
  standalone `Anpr_system` project; genuine local inference, no API key
  needed.
- ANPR plate OCR — real cloud call to the Plate Recognizer API, same as
  the source project's `image_anpr.py`. The custom YOLO model was never
  trained to localize plates, so this stage needs
  `PLATE_RECOGNIZER_API_TOKEN` set in the environment; without it, the
  vehicle-type detection still runs for real and still logs an event, the
  plate just reads `NOT-READ` instead of being invented.
- Watchlist matching against a sample plate list (`anpr.py:
  WATCHLIST_PLATES`) — swap in a real watchlist source for production use.

**Simulated, sample-data-driven (clearly out of scope for a from-scratch
model here — Face says so in the UI):**
- Face detection & watchlist matching — `simulators.py: FaceSimulator`
- CAM-02/03/04 — loop the bundled demo clip with a scripted overlay box,
  since running YOLO on 4 streams isn't the point of this prototype
- Network bandwidth/health widget — client-side simulated telemetry

Crucially, the simulated modules still go through the **same** real
`EventLogger` — same SQLite table, same JPEG snapshotting, same hash
chain — so the "evidence trail" and tamper-detection story is one
consistent system end to end, even though the detections themselves are
scripted for the modules that were explicitly out of scope.

## Setup

```bash
pip install -r requirements.txt

# optional: enables real plate OCR (see "What's real vs simulated" above)
export PLATE_RECOGNIZER_API_TOKEN=your_token_here

python app.py
```

Open **http://localhost:5000**. `models/yolov8n.pt` is bundled; if
missing, ultralytics downloads it automatically on first run.
`models/anpr_best.pt` (custom vehicle-type model) is also bundled.

## Using it

- **CAM-01 (hero tile)**: "Use webcam" for a live demo, "Use sample clip"
  for the bundled `uploads/demo.mp4` (no camera needed), or upload your
  own footage.
- **Virtual fence**: in the *Virtual Fence* module tab, click "Draw
  virtual fence", click 3+ points on CAM-01, click again to save. Anyone
  whose tracked position enters that zone fires a Fence Intrusion event.
- **AI Model buttons**: one per capability from the problem statement —
  Human Tracking, Vehicle Detection, ANPR, Face Detection, Virtual Fence,
  Suspicious Activity, Night Vision — each opens its own panel/table.
- **Network Health tab**: aggregate bandwidth, latency, packet loss, and
  adaptive stream-quality label (simulated).
- **Event log (right sidebar)**: every event — real or simulated — with
  timestamp, alert type, description, snapshot, camera tag, short hash,
  and filter chips by module. Critical events also pop a toast alert.
  Chain integrity is polled every 15s and shown as a badge at the top.

## Architecture

```
CAM-01: Webcam / video file
      │
      ▼
YOLOv8n (person detection)  ── app.py: VideoProcessor
      │
      ▼
Centroid tracker (tracker.py) — stable ID + motion history per person
      │
      ▼
SuspiciousActivityDetector (analytics.py)
  ├─ point-in-polygon virtual fence check
  ├─ dwell-radius loitering check
  ├─ speed-based running check
  └─ frame-brightness night check
      │
CAM-02/03/04 (simulators.py: SimulatedCamera) ─┐
ANPRProcessor (anpr.py, real) / ───────────────┤
FaceSimulator (simulators.py, scripted) ───────┤
      │                                        │
      ▼                                        ▼
              EventLogger (analytics.py)
              SQLite (events.db) + JPEG snapshots (events/)
              + SHA-256 hash chain (prev_hash → event_hash)
      │
      ▼
Flask REST API + MJPEG streams → dashboard (templates/index.html)
```

## Notes for the demo

- Runs on CPU — no GPU needed for `yolov8n`, though ultralytics will use
  CUDA automatically if available.
- If FPS is low, raise `PROCESS_EVERY_N_FRAMES` in `app.py`.
- CAM-01's pipeline is camera-agnostic — the same code runs against any
  IP-CCTV's RTSP stream by passing the RTSP URL as the video source
  instead of a webcam index or file path.
- `/api/integrity` is a good live demo moment: open it, then edit a file
  in `events/` and refresh — the badge in the sidebar flips to
  "TAMPER DETECTED" within 15s.
