"""
app.py — IBVAP prototype server
Human detection & tracking + suspicious movement detection + event logging
with snapshots, served as a live web dashboard.

Run:
    python3 app.py
Then open http://localhost:5000

Video source:
  - Default: webcam index 0 (works on your laptop for a live demo)
  - Or upload a video clip from the dashboard ("Use uploaded video")
"""
import os
import time
import threading

import cv2
from flask import Flask, Response, render_template, request, jsonify, send_from_directory
from ultralytics import YOLO

from tracker import CentroidTracker
from analytics import SuspiciousActivityDetector, EventLogger, SNAPSHOT_DIR, point_in_polygon
from simulators import SimulatedCamera, FaceSimulator
from anpr import ANPRProcessor

BASE_DIR = os.path.dirname(__file__)
MODEL_PATH = os.path.join(BASE_DIR, "models", "yolov8n.pt")
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

CAMERAS = [
    {"id": "CAM-01", "name": "BOP Alpha — Main Gate", "location": "Border Out Post Alpha", "kind": "live"},
    {"id": "CAM-02", "name": "Check Post Bravo", "location": "Vehicle Check Post Bravo", "kind": "sim"},
    {"id": "CAM-03", "name": "Border Road Charlie", "location": "Patrol Road Charlie", "kind": "sim"},
    {"id": "CAM-04", "name": "Watchtower Delta", "location": "Watchtower Delta — Fence Line", "kind": "sim"},
]

app = Flask(__name__)
PERSON_CLASS_ID = 0
CONF_THRESHOLD = 0.4
PROCESS_EVERY_N_FRAMES = 1  # raise this (e.g. 2-3) on slower machines


class VideoProcessor:
    """
    Owns the capture device/file, runs YOLO + tracking + analytics on a
    background thread, and exposes the latest annotated JPEG frame plus
    live stats to the Flask routes.
    """

    def __init__(self):
        self.model = YOLO(MODEL_PATH)
        self.tracker = CentroidTracker()
        self.logger = EventLogger()
        self.detector = SuspiciousActivityDetector(logger=self.logger)

        self.cap = None
        self.source_desc = "No source"
        self.lock = threading.Lock()
        self.latest_jpeg = None
        self.running = False
        self.thread = None
        self.frame_count = 0
        self.fps = 0.0
        self.night_mode = False
        self.active_people = 0
        self.last_alerts = []
        self._last_fps_t = time.time()
        self._last_fps_n = 0

    # ---- source management -------------------------------------------------
    def set_source(self, source, desc):
        with self.lock:
            if self.cap is not None:
                self.cap.release()
            self.cap = cv2.VideoCapture(source)
            self.source_desc = desc
            self.tracker = CentroidTracker()  # fresh tracks for a new source

    def start(self):
        if self.thread and self.thread.is_alive():
            return
        self.running = True
        self.thread = threading.Thread(target=self._loop, daemon=True)
        self.thread.start()

    def stop(self):
        self.running = False

    # ---- processing loop -----------------------------------------------------
    def _loop(self):
        while self.running:
            with self.lock:
                cap = self.cap
            if cap is None or not cap.isOpened():
                time.sleep(0.2)
                continue

            ok, frame = cap.read()
            if not ok:
                # loop uploaded video files for a continuous demo
                cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                time.sleep(0.05)
                continue

            self.frame_count += 1
            if self.frame_count % PROCESS_EVERY_N_FRAMES != 0:
                continue

            results = self.model(frame, verbose=False, classes=[PERSON_CLASS_ID], conf=CONF_THRESHOLD)
            bboxes = []
            if len(results) and results[0].boxes is not None:
                for b in results[0].boxes.xyxy.tolist():
                    bboxes.append(tuple(b))

            tracks = self.tracker.update(bboxes)
            fired, night_mode = self.detector.evaluate(tracks, frame, camera_id="CAM-01")

            annotated = self._annotate(frame, tracks, night_mode)

            with self.lock:
                self.night_mode = night_mode
                self.active_people = len(tracks)
                if fired:
                    self.last_alerts = (fired + self.last_alerts)[:5]
                ok2, buf = cv2.imencode(".jpg", annotated, [cv2.IMWRITE_JPEG_QUALITY, 80])
                if ok2:
                    self.latest_jpeg = buf.tobytes()

            self._last_fps_n += 1
            now = time.time()
            if now - self._last_fps_t >= 1.0:
                self.fps = self._last_fps_n / (now - self._last_fps_t)
                self._last_fps_n = 0
                self._last_fps_t = now

    def _annotate(self, frame, tracks, night_mode):
        out = frame.copy()

        # virtual fence
        if self.detector.fence_polygon:
            pts = self.detector.fence_polygon
            for i in range(len(pts)):
                p1 = tuple(map(int, pts[i]))
                p2 = tuple(map(int, pts[(i + 1) % len(pts)]))
                cv2.line(out, p1, p2, (0, 0, 255), 2)

        for t in tracks.values():
            if t.disappeared > 0:
                continue
            x1, y1, x2, y2 = map(int, t.bbox)
            speed = t.speed_px_per_s()
            span, duration = t.dwell_radius_px(window_s=self.detector.thresholds["loiter_seconds"])
            color = (60, 220, 60)
            label = f"ID {t.id}"
            if self.detector.fence_polygon and point_in_polygon(t.centroid, self.detector.fence_polygon):
                color = (0, 0, 255)
                label += " INTRUSION"
            elif speed > self.detector.thresholds["run_speed_px_s"]:
                color = (0, 165, 255)
                label += " FAST"
            elif span is not None and duration >= self.detector.thresholds["loiter_seconds"] * 0.9 and span <= self.detector.thresholds["loiter_radius_px"]:
                color = (0, 255, 255)
                label += " LOITER"

            cv2.rectangle(out, (x1, y1), (x2, y2), color, 2)
            cv2.putText(out, label, (x1, max(y1 - 8, 12)), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
            # short motion trail
            pts = [(int(x), int(y)) for x, y, _ in list(t.history)[-15:]]
            for i in range(1, len(pts)):
                cv2.line(out, pts[i - 1], pts[i], color, 1)

        banner = f"PEHREDAR.AI · CAM-01  |  People: {len(tracks)}  |  {'NIGHT MODE' if night_mode else 'DAY'}  |  FPS: {self.fps:.1f}"
        cv2.rectangle(out, (0, 0), (out.shape[1], 26), (20, 20, 20), -1)
        cv2.putText(out, banner, (8, 18), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 140), 1)
        return out

    def mjpeg_generator(self):
        while True:
            with self.lock:
                frame = self.latest_jpeg
            if frame is None:
                time.sleep(0.05)
                continue
            yield (b"--frame\r\nContent-Type: image/jpeg\r\n\r\n" + frame + b"\r\n")
            time.sleep(0.03)


processor = VideoProcessor()

DEMO_CLIP = os.path.join(UPLOAD_DIR, "demo.mp4")
sim_cameras = {
    "CAM-02": SimulatedCamera("CAM-02 · Check Post Bravo", DEMO_CLIP, seed=1),
    "CAM-03": SimulatedCamera("CAM-03 · Border Road Charlie", DEMO_CLIP, seed=2),
    "CAM-04": SimulatedCamera("CAM-04 · Watchtower Delta", DEMO_CLIP, seed=3),
}
vehicle_anpr = ANPRProcessor(processor.logger, DEMO_CLIP, camera_id="CAM-02")
face_sim = FaceSimulator(processor.logger, camera_id="CAM-04")


def _default_source():
    """Prefer a webcam if one is actually available; otherwise fall back
    to the bundled demo clip so the dashboard is never blank."""
    test = cv2.VideoCapture(0)
    if test.isOpened():
        test.release()
        return 0, "Webcam 0 (live)"
    demo = os.path.join(UPLOAD_DIR, "demo.mp4")
    if os.path.exists(demo):
        return demo, "Sample clip (demo.mp4)"
    return 0, "Webcam 0 (live)"


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/video_feed")
def video_feed():
    return Response(processor.mjpeg_generator(), mimetype="multipart/x-mixed-replace; boundary=frame")


@app.route("/api/status")
def status():
    with processor.lock:
        return jsonify(
            {
                "source": processor.source_desc,
                "fps": round(processor.fps, 1),
                "active_people": processor.active_people,
                "night_mode": processor.night_mode,
                "fence_set": bool(processor.detector.fence_polygon),
                "thresholds": processor.detector.thresholds,
                "last_alerts": processor.last_alerts,
            }
        )


@app.route("/api/events")
def events():
    since_id = int(request.args.get("since", 0))
    return jsonify(processor.logger.recent(since_id=since_id, limit=200))


@app.route("/api/events/stats")
def events_stats():
    return jsonify(processor.logger.stats())


@app.route("/events/<path:filename>")
def snapshot(filename):
    return send_from_directory(SNAPSHOT_DIR, filename)


@app.route("/api/fence", methods=["POST"])
def set_fence():
    points = request.json.get("points", [])
    processor.detector.set_fence(points)
    return jsonify({"ok": True, "points": points})


@app.route("/api/thresholds", methods=["POST"])
def set_thresholds():
    data = request.json or {}
    processor.detector.thresholds.update(
        {k: float(v) for k, v in data.items() if k in processor.detector.thresholds}
    )
    return jsonify({"ok": True, "thresholds": processor.detector.thresholds})


@app.route("/api/source/webcam", methods=["POST"])
def use_webcam():
    idx = int(request.json.get("index", 0)) if request.is_json else 0
    processor.set_source(idx, f"Webcam {idx} (live)")
    return jsonify({"ok": True})


@app.route("/api/source/demo", methods=["POST"])
def use_demo():
    demo = os.path.join(UPLOAD_DIR, "demo.mp4")
    processor.set_source(demo, "Sample clip (demo.mp4)")
    return jsonify({"ok": True})


@app.route("/upload", methods=["POST"])
def upload():
    f = request.files.get("video")
    if not f:
        return jsonify({"ok": False, "error": "No file"}), 400
    path = os.path.join(UPLOAD_DIR, f.filename)
    f.save(path)
    processor.set_source(path, f"Uploaded: {f.filename}")
    return jsonify({"ok": True, "source": f.filename})


@app.route("/api/cameras")
def cameras():
    return jsonify(CAMERAS)


@app.route("/cam/<cam_id>/feed")
def cam_feed(cam_id):
    cam = sim_cameras.get(cam_id)
    if cam is None:
        return "Unknown camera", 404
    return Response(cam.mjpeg_generator(), mimetype="multipart/x-mixed-replace; boundary=frame")


@app.route("/api/integrity")
def integrity():
    return jsonify(processor.logger.verify_chain())


if __name__ == "__main__":
    src, desc = _default_source()
    processor.set_source(src, desc)
    processor.start()
    vehicle_anpr.start()
    face_sim.start()
    app.run(host="0.0.0.0", port=5000, threaded=True, debug=False)
